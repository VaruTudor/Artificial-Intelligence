K = 4
FILE_NAME = 'utils/dataset.csv'
COLORS = ['blue',
          'green',
          'red',
          'cyan',
          'magenta',
          'white',
          'yellow',
          'black']

MAX_ITERATIONS = 300

MAX_K = COLORS.__len__()

NUMBER_DECIMAL_DIGITS = 6